/*
  Warnings:

  - You are about to drop the column `barch` on the `students` table. All the data in the column will be lost.
  - Added the required column `barnch` to the `students` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `students` DROP COLUMN `barch`,
    ADD COLUMN `barnch` VARCHAR(191) NOT NULL;
