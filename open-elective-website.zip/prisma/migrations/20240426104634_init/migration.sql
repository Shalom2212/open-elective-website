/*
  Warnings:

  - You are about to drop the column `barnch` on the `students` table. All the data in the column will be lost.
  - Added the required column `branch` to the `students` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE `students` DROP COLUMN `barnch`,
    ADD COLUMN `branch` VARCHAR(191) NOT NULL;
